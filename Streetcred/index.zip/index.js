module.exports = async function (context, req) {
  context.log('JavaScript HTTP trigger function processed a request.');
  require('dotenv').config();

  const {
    AgencyServiceClient,
    Credentials,
  } = require('@streetcred.id/service-clients');
  const client = new AgencyServiceClient(
    new Credentials(process.env.ACCESSTOK, process.env.SUBKEY)
  );

  let x = '';

  let verId = 'b7054383-9140-40b4-8bc0-70fff3c5d4a9';
  let connId = 'cb79ecf0-9f84-459a-b608-073a7ed90bac';
  let connData = {
    connectionId: connId,
  };
  let connPayload = JSON.stringify(connData);
  context.log('conn payload:', connPayload);

  verData = {
    verificationId: verId,
  };
  let verPayload = JSON.stringify(verData);
  context.log('ver payload:', verPayload);

  if (connId) {
    //x = await client.listMessages(connPayload); //returns empty but this works in Postman: https://api.streetcred.id/agency/v1/messages/connection/cb79ecf0-9f84-459a-b608-073a7ed90bac

    // x = await client.listVerificationsForConnection(connPayload); // Cannot use 'in' operator to search for 'connectionId' in {"connectionId":"cb79ecf0-9f84-459a-b608-073a7ed90bac"}
    x = await client.listVerificationsForConnection(connData); // returns data
  } else if (verId) {
    // this works in postman: https://api.streetcred.id/agency/v1/verifications/b7054383-9140-40b4-8bc0-70fff3c5d4a9
    x = await client.getVerification(verPayload); // {"error":"Verification record not found","errorType":"Exception"}

    //Exception: Error: verificationId with value "[object Object]" must be of type string.
    // x = await client.getVerification(verData);
  }

  context.log('results:', x);
  context.res = {
    body: x,
    headers: {
      'Content-Type': 'application/json',
    },
  };
  context.done();
};
